const increaseButtonEl = document.querySelector(".counter_button--increase");
const decreaseButtonEl = document.querySelector(".counter_button--decrease");
const resetButtonEl = document.querySelector(".counter_reset-button");
const counterValueEl = document.querySelector(".counter_value");
const counterTitleEl = document.querySelector(".counter_title"); 
resetButtonEl.addEventListener("click", function () {
  counterValueEl.textContent = 0;
  counterTitleEl.textContent = "Fancy Counter"; 
});


decreaseButtonEl.addEventListener("click", function () {
  const currentValueAsNumber = +counterValueEl.textContent;
  let newValue = currentValueAsNumber - 1;
  
  if (newValue < 0) {
    newValue = 0;
  }
  
  counterValueEl.textContent = newValue;
  

  if (newValue < 5) {
    counterTitleEl.textContent = "Fancy Counter";
  }
});


increaseButtonEl.addEventListener("click", function () {
  const currentValueAsNumber = +counterValueEl.textContent;
  
  if (currentValueAsNumber >= 5) {
      return;
  }

  const newValue = currentValueAsNumber + 1;
  counterValueEl.textContent = newValue;


  if (newValue === 5) {
    counterTitleEl.textContent = "LIMIT! BUY PRO FOR >5";
  }
});


document.addEventListener("keyup", function () {
  const currentValueAsNumber = +counterValueEl.textContent;

  if (currentValueAsNumber >= 5) {
      return;
  }

  const newValue = currentValueAsNumber + 1;
  counterValueEl.textContent = newValue;

  if (newValue === 5) {
    counterTitleEl.textContent = "LIMIT! BUY PRO FOR >5";
  }
});