const increaseButtonEl = document.querySelector(".counter_button--increase");
const decreaseButtonEl = document.querySelector(".counter_button--decrease");
const resetButtonEl = document.querySelector(".counter_reset-button");
const counterValueEl = document.querySelector(".counter_value");


resetButtonEl.addEventListener("click", function () {
  counterValueEl.textContent = 0;
});


decreaseButtonEl.addEventListener("click", function () {
  let currentValue = +counterValueEl.textContent;
  let newValue = currentValue - 1;

  if (newValue < 0) {
    newValue = 0;
  }

  counterValueEl.textContent = newValue;
});


increaseButtonEl.addEventListener("click", function () {
  let currentValue = +counterValueEl.textContent;
  let newValue = currentValue + 1;

  counterValueEl.textContent = newValue;
});


document.addEventListener("keydown", function (event) {
  let currentValue = +counterValueEl.textContent;

  if (event.key === "ArrowUp") {
    counterValueEl.textContent = currentValue + 1;
  }

  if (event.key === "ArrowDown") {
    let newValue = currentValue - 1;

    if (newValue < 0) {
      newValue = 0;
    }

    counterValueEl.textContent = newValue;
  }
});