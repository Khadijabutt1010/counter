const counterEl = document.querySelector("#counter");
const btnIncrease = document.querySelector(".counter_button--increase");
const btnDecrease = document.querySelector(".counter_button--decrease");
const btnReset = document.querySelector(".counter_reset-button");


let value = 0;


const updateUI = () => {
  counterEl.textContent = value;
};


const increase = () => {
  value++;
  updateUI();
};

const decrease = () => {
  if (value > 0) value--;
  updateUI();
};

const reset = () => {
  value = 0;
  updateUI();
};


btnIncrease.addEventListener("click", increase);
btnDecrease.addEventListener("click", decrease);
btnReset.addEventListener("click", reset);


document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowUp") increase();
  if (e.key === "ArrowDown") decrease();
  if (e.key.toLowerCase() === "r") reset();
});